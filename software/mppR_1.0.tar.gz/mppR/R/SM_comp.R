##########
# SM_comp #
##########

#'
#' Simple matching coefficient
#'
#' Computes the simple matching coefficient from a SNP marker matrix.
#' 
#' @param mk.mat \code{Character} genotype  marker score \code{matrix}.
#' \strong{Marker scores must be coded using one letter for each allele.
#' For example, AA, CC, GG, TT, AC, AG, AT, CA, CG, CT, GA, GC, GT, TA, TC, TG.
#' Missing values must be coded NA.}
#' 
#' @return Return:
#' 
#' \item{kin.mat }{Kinship matrix computed using simple matching}
#' 
#' @author Vincent Garin
#' 
#' @examples
#'
#' # No example for the moment
#'  
#' @export

SM_comp <- function(mk.mat){
  
  # get the genotypes names
  
  geno.names <- rownames(mk.mat)
  
  # transform matrix into 012 format
  
  mk.mat <- geno_012(mk.mat = mk.mat)[[1]]
  
  # perform the dice computation
  
  pos.dice <- function(n) {
    
    p1 <- p2 <- c()
    
    for(i in 2:n){
      
      p1 <- c(p1, rep((i-1), (n-(i-1))))
      p2 <- c(p2, (i:n))
      
    }
    
    return(cbind(p1, p2))
    
  }
  
  n.gen <- dim(mk.mat)[1]
  
  # compose the vector of positions
  
  pos <- pos.dice(n = n.gen)
  
  sg.pos.dice <- function(x, mk.mat){
    
    data.i <- data.frame(mk.mat[x[1], ], mk.mat[x[2], ])
    data.i <- data.i[complete.cases(data.i), ]
    
    sum((data.i[, 1] - data.i[, 2]) == 0) / dim(data.i)[1]
    
  }
  
  dice.score <- apply(X = pos, MARGIN = 1, FUN = sg.pos.dice,
                      mk.mat = mk.mat)
  
  empt.mat <- matrix(0, n.gen, n.gen)
  
  for(i in 1:length(dice.score)){
    
    empt.mat[pos[i, 1], pos[i, 2]] <- dice.score[i]
    
  }
  
  kin.mat <- empt.mat + t(empt.mat) + diag(n.gen)
  
  kin.mat <- data.matrix(kin.mat)
  
  rownames(kin.mat) <- colnames(kin.mat) <- attr(kin.mat,"rowNames") <- geno.names
  
  return(kin.mat)
  
}