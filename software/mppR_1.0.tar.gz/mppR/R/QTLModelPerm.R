################
# QTLModelPerm #
################

# function to compute a single position QTL model

QTLModelPerm <- function(x, mppData, cross.mat, par.mat, Q.eff, par.clu, VCOV,
                         V, W.Bc){
  
  # 1. formation of the QTL incidence matrix
  ###########################################
  
  QTL <- IncMat_QTL(x = x, mppData = mppData, cross.mat = cross.mat,
                    par.mat = par.mat, par.clu = par.clu, Q.eff = Q.eff,
                    order.Qmat = TRUE)
  
  # 2. model computation
  ######################
  
  ### 2.1 homogeneous residual variance error
  
  if(VCOV == "h.err"){
    
    model <- tryCatch(expr = lm(mppData$trait[, 1] ~ -1 + cross.mat + QTL),
                      error = function(e) NULL)
    
    if (is.null(model)){ results <- 0
    
    } else { results <- -log10(anova(model)$Pr[2]) }
    
    ### 2.2 HRT REML or cross-specific variance residual terms
    
  } else if ((VCOV == "h.err.as") || (VCOV == "cr.err")){
    
    dataset <- data.frame(QTL = QTL,
                          cr.mat = factor(mppData$cross.ind,
                                          levels = unique(mppData$cross.ind)),
                          trait = mppData$trait[, 1])
    
    if(VCOV == "h.err.as"){ formula.R <- "~idv(units)"
    } else if (VCOV == "cr.err") {formula.R <- "~at(cr.mat):units"}
    
    
    model <- tryCatch(expr = asreml(fixed = trait ~ -1 + cr.mat + grp(QTL),
                                    rcov =  as.formula(formula.R),
                                    group = list(QTL = 1:dim(QTL)[2]),
                                    data=dataset, trace = FALSE,
                                    na.method.Y = "omit",
                                    na.method.X = "omit"),
                      error = function(e) NULL)
    
    
    ### 2.3 random pedigree + HVRT or + CSRT
    
  } else if ((VCOV == "pedigree") || (VCOV == "ped_cr.err")){
    
    # compose the dataset for the asreml function
    
    dataset <- data.frame(QTL = QTL, trait = mppData$trait[, 1],
                          cr.mat = factor(mppData$cross.ind,
                                          levels = unique(mppData$cross.ind)),
                          genotype = mppData$geno.id)
    
    if(VCOV == "pedigree"){ formula.R <- "~idv(units)"
    } else if (VCOV == "ped_cr.err") {formula.R <- "~at(cr.mat):units"}
    
    model <- tryCatch(expr = asreml(fixed = trait ~ 1 + grp(QTL),
                                    random = ~ ped(genotype),
                                    rcov =  as.formula(formula.R),
                                    group = list(QTL=1:dim(QTL)[2]),
                                    ginverse = list(genotype = ped.mat.inv),
                                    data = dataset, trace = FALSE,
                                    na.method.Y = "omit",
                                    na.method.X = "omit"),
                      error = function(e) NULL)
    
  } else if (VCOV == "cr.err_fast"){
    
    
    ref.names <- c(colnames(cross.mat), rep("QTL", dim(QTL)[2]))
    
    X.mat <- cbind(cross.mat, QTL)
    model.sg <- lm(mppData$trait[, 1] ~ -1 + X.mat)
    index <- !is.na(coefficients(model.sg))
    X.mat <- X.mat[, index]
    
    df <- table(ref.names[index])[names(table(ref.names[index])) == "QTL"]
    
    # compute W.B
    
    W.B <- tryCatch(expr = Wald_CSRT(y = mppData$trait[, 1],
                                     X = X.mat, V.inv = V),
                    error = function(e) NULL)
    
    # compute the test statistics
    
    if(!is.null(W.B)){
      
      W.Bq <- W.B - W.Bc
      pval <- pchisq(W.Bq, df, lower.tail = FALSE)
      results <- -log10(pval)
      
    } else {results <- 0}
    
  }
  
  if((VCOV != "h.err") & (VCOV != "cr.err_fast")){
    
    if (is.null(model)){ results <- 0
    
    } else { pval <- pchisq(wald(model)[2, 3], wald(model)[2, 1],
                            lower.tail = FALSE)
    results <- -log10(pval)
    
    }
    
  }
  
  return(results)
  
}