#############
# Wald_CSRT #
#############

# function for the Wald test

Wald_CSRT <- function(y, X, V.inv){
  
  t(y) %*% V.inv %*% X %*% 
    chol2inv(chol(t(X) %*% V.inv %*% X)) %*% t(X) %*% V.inv %*% y
  
}