##########
# MQE_CV #
##########

#' Multi-QTL effect model cross-validation
#' 
#' Evaluation of multi-QTL effect model (MQE) QTL detection procedure by
#' cross-validation (CV). For details on the MQE model see
#' \code{\link{MQE_forward}} documentation. The CV scheme is adapted from Utz
#' et al. (2000).
#' 
#' A single CV run works like that:
#' 
#' \enumerate{
#' 
#' \item{Generation of a k-fold partition of the data. The partition is done
#' within crosses. Each cross is divided into k subsets. Then for the kth
#' repetition, the kth subset is used as validation set, the rest goes into the
#' training set.}
#' 
#' \item{For the kth repetition, utilisation of the training set to determine a
#' multi-QTL effect model with different type of QTL effects (\code{Q.eff}) at
#' different loci (\code{\link{MQE_forward}}). If \code{backward = TRUE}, the
#' final list of QTLs is tested simultaneously using a backward elimination
#' (\code{\link{MQE_BackElim}}).}
#' 
#' \item{Use the list of detected QTLs in the training sets to calculate
#' the proportion of genetic variance explained by all detected QTLs in the
#' training set (p.ts = R2.ts/h2). Where R2.ts is the adjusted
#' R squared and h2 is the average within cross heritability (\code{her}).
#' 
#' For each single QTL effect, difference partial R squared are also
#' calculated. Difference R squared are computed by doing the difference between
#' a model with all QTLs and a model without the ith position. For details
#' about R squared computation and adjustment look at \code{\link{QTL_R2}}.}
#' 
#' \item{Use the estimates of the QTL effects in the training set (B.ts) to
#' predict the phenotypic values of the validation set. y.pred.vs = X.vs*B.ts.
#' Computes the predicted R squared  in the validation set using the squared
#' Pearson correlation coefficient between the real values (y.vs) and the
#' predicted values (y.pred.vs). R2.vs = cor(y.ts,y.pred.ts)^2. Then
#' the predicted genetic variance in the validation set (p.vs) is equal to
#' p.vs = R2.vs/h2. For heritability correction, the user can provide a single
#' value for the average within cross heritability or a vector specifying each
#' within cross heritability.
#' 
#' The predicted R squared is computed per cross and then averaged
#' at the population level (p.ts). Both results are returned. Partial QTL
#' predicted R squared are also calculated using the difference between the
#' predicted R squared using all QTL and the predicted R squared without QTL i.
#' 
#' The bias between p.ts and p.vs is calculated as bias = 1 - (p.vs/p.ts).
#' 
#'   }
#' 
#' }
#' 
#' \strong{WARNING!(1)} The computation of \code{MQE_CV()} function using mixed
#' models (all models with \code{VCOV} different than \code{"h.err"})
#' is technically possible but can be irrealistic
#' in practice due to a reduced computer power. Since a mixed model is computed at
#' each single position it can take a lot of time. From our estimation it can take
#' between 20 to 50 times more time than for linear models.
#' 
#' \strong{WARNING! (2)} The estimation of the random pedigree models
#' (\code{VCOV = "pedigree" and "ped_cr.err"}) can be unstable. Sometimes the
#' \code{asreml()} function fails to produce a results and returns the following
#' message: \strong{\code{GIV matrix not positive definite: Singular pivots}}.
#' So far we were not able to identify the reason of this problem and to
#' reproduce this error because it seems to happen randomly. The consequence of
#' this is that part of the results of the CV procedure can not be produced.
#' 
#' 
#' @param pop.name \code{Character} name of the studied population.
#' Default = "MPP".
#' 
#' @param trait.name \code{Character} name of the studied trait.
#' Default = "trait1".
#' 
#' @param mppData An IBD object of class \code{mppData}
#' See \code{\link{mppData_form}} for details. Default = NULL.
#'
#' @param mppData_bi Required IBS object of class \code{mppData} if the user
#' wants to allow QTLs with a bi-allelic effect. \strong{The list of marker must
#' be strictly the same as the one of \code{mppData}.} Default = NULL.
#' 
#' @param her \code{Numeric} value between 0 and 1 representing the heritability
#' of the trait. \code{her} can be a single value or a vector specifying each
#' within cross heritability. \strong{By default, the heritability is set to 1
#' (\code{her = 1}). This means that the results represent the proportion of
#' phenotypic variance explained (predicted) in the training (validation) sets.}
#' 
#' @param Rep \code{Numeric} value representing the number of repetition of the
#' k-fold procedure. Default = 10.
#' 
#' @param k \code{Numeric} value representing the number of folds for the within
#' cross partition of the population. Default = 5.
#' 
#' @param Q.eff \code{Character} vector of possible QTL effects the user want to
#' test. Elements of Q.eff can be "cr", "par", "anc" or "biall". For details
#' look at \code{\link{mpp_SIM}}.
#' 
#' @param par.clu Required argument for the ancesral model \code{(Q.eff = "anc")}.
#' \code{interger matrix} representing the results of a parents genotypes
#' clustering. The columns represent the parental lines and the rows
#' the different markers or in between positions. \strong{The columns names must
#' be the same as the parents list of the mppData object. The rownames must be
#' the same as the map marker list of the mppData object.} At a particular
#' position, parents with the same value are assumed to inherit from the same
#' ancestor. for more details, see \code{\link{USNAM_parClu}} and
#' \code{\link{parent_cluster}}. Default = NULL.
#'
#' @param VCOV \code{Character} expression defining the type of variance
#' covariance structure used: 1) "h.err" for an homogeneous variance residual term
#' (HRT) linear model; 2) "h.err.as" for a HRT model fitted by REML using
#' \code{ASReml-R}; 3) "cr.err" for a cross-specific variance residual terms
#' (CSRT) model; 4) "cr.err_fast" for a "fast" CSRT model; 5) "pedigree" for a
#' random pedigree term and HRT model; and 6) "ped_cr.err" for random pedigree
#' and CSRT model. For more details see \code{\link{mpp_SIM}}. Default = "h.err".
#' 
#' @param threshold \code{Numeric} value representing the -log10(p-value)
#' threshold above which a position can be considered as significant.
#' Significance threshold values can be obtained by permutation using
#' \code{\link{mpp_perm}} function. Default = 3.
#' 
#' @param window \code{Numeric} value in centi-Morgan representing the distance
#' on the left an right of a cofactor position where it is not included in the
#' model. Default value = 20.
#' 
#' @param backward \code{Logical} value. If \code{backward = TRUE},
#' the function performs a backward elimination on the list of selected QTLs.
#' Default = TRUE.
#' 
#' @param alpha.bk \code{Numeric} value indicating the significance level for
#' the backward elimination. Terms with p-values above this value will
#' iteratively be removed. Default = 0.05.
#' 
#' @param parallel \code{Logical} value specifying if the function should be
#' executed in parallel on multiple cores. To run function in parallel user must
#' provide cluster in the \code{cluster} argument. \strong{Parallelization is
#' only available for HRT (linear) models \code{VCOV = "h.err"}}.
#' Default = FALSE.
#' 
#' @param cluster Cluster object obtained with the function \code{makeCluster()}
#' from the \code{parallel} package. Default = NULL.
#' 
#' @param silence.print \code{logical} value specifying if the printing of the
#' \code{MQE_proc()} function must be silenced. It will not
#' affect the printing of the other functions called by \code{MQE_CV()},
#' especially the printing of \code{asreml()}. Default = FALSE.
#' 
#' @param output.loc Path where a folder will be created to save the results.
#' By default the function uses the current working directory.
#' 
#' 
#' @return 
#' 
#' \code{List} containing the following results items:
#' 
#' \item{CV_res}{\code{Data.frame} containing for each CV run: 1) the number
#' of detected QTL; 2) the proportion of explained genetic variance in the TS;
#' 3) the proportion of predicted genetic variance in the VS p.vs at the
#' population level (average of within cross prediction); the bias between
#' p.ts and p.vs (bias = 1-(p.vs/p.ts))}
#' 
#' \item{p.vs.cr}{\code{Matrix} containing the within cross p.vs for each CV run}
#' 
#' \item{QTL}{\code{Data.frame} containing: 1) the list of QTL position detected
#' at least one time during the entire CV process; 2) The number of times
#' the position has been detected; 3) The number of time the position is
#' detected as a cross-specific QTL; 4) a parental QTL; 5) an ancestral QTL;
#' 6) a bi-allelic QTL; 7) the average p.ts of the QTL position;
#' 8) the average p.vs of the QTL position; 5) the average bias of the QTL
#' position}
#' 
#' The results elements return as R object are also saved as text
#' files at the specified output location (\code{output.loc}).
#' 
#' @author Vincent Garin
#' 
#' @references
#' 
#' Utz, H. F., Melchinger, A. E., & Schon, C. C. (2000). Bias and sampling error
#' of the estimated proportion of genotypic variance explained by quantitative
#' trait loci determined from experimental data in maize using cross validation
#' and validation with independent samples. Genetics, 154(4), 1839-1849.
#' 
#' @seealso \code{\link{mppData_form}},
#' \code{\link{MQE_forward}}, \code{\link{MQE_BackElim}},
#' \code{\link{MQE_genEffects}},  \code{\link{MQE_R2}},
#' \code{\link{parent_cluster}}, \code{\link{QTL_R2}},
#' \code{\link{USNAM_parClu}}
#' 
#' @examples
#' 
#' data(USNAM_mppData)
#' data(USNAM_mppData_bi)
#' data(USNAM_parClu)
#' 
#' mppData <- USNAM_mppData
#' mppData_bi <- USNAM_mppData_bi
#' par.clu <- USNAM_parClu
#' 
#' 
#' # Equalize the list of markers of the two mppData objects and par.clu
#' 
#' com.mk.list <- intersect(mppData$map$mk.names, mppData_bi$map$mk.names)
#' 
#' mppData <- mppData_subset(mppData = mppData, mk.list = com.mk.list)
#' mppData_bi <- mppData_subset(mppData = mppData_bi, mk.list = com.mk.list)
#' par.clu <- par.clu[rownames(par.clu) %in% com.mk.list, ]
#' 
#' \dontrun{
#' 
#' # Specify a location where your results will be saved
#' my.loc <- "C:/.../..."
#' 
#' MQE <- MQE_CV(mppData = mppData, mppData_bi = mppData_bi, her = 0.5, Rep = 1,
#'               k = 5, Q.eff = c("par", "anc", "biall"), par.clu = par.clu,
#'               VCOV = "h.err", window = 20, output.loc = my.loc)
#' 
#' 
#' # Using parallel
#' 
#' library(parallel)
#' n.cores <- detectCores()
#' cluster <- makeCluster(n.cores-1)
#' 
#' MQE <- MQE_CV(mppData = mppData, mppData_bi = mppData_bi, her = 0.5, Rep = 1,
#'               k = 5, Q.eff = c("par", "anc", "biall"), par.clu = par.clu,
#'               VCOV = "h.err", window = 20, parallel = TRUE, cluster = cluster,
#'               output.loc = my.loc)
#' 
#' }
#' 
#' 
#' @export
#'


MQE_CV <- function(pop.name = "MPP", trait.name = "trait1",
                   mppData = NULL, mppData_bi = NULL, her = 1, Rep = 10,
                   k = 5, Q.eff, par.clu = NULL, VCOV = "h.err", threshold = 3,
                   window = 20, backward = TRUE, alpha.bk = 0.05,
                   parallel = FALSE, cluster = NULL, silence.print = FALSE,
                   output.loc = getwd()) {
  
  if ((VCOV == "cr.err") || (VCOV == "cr.err_fast")){ ind.R2 <- TRUE
  } else {ind.R2 <- FALSE}
  
  # 1. Check the validity of the parameters that have been introduced
  ###################################################################
  
  if(VCOV == "cr.err_fast") VCOV_test <- "h.err" else VCOV_test <- VCOV
  
  check.MQE(mppData = mppData, mppData_bi = mppData_bi, Q.eff = Q.eff,
            VCOV = VCOV_test, par.clu = par.clu, parallel = parallel,
            cluster = cluster, output.loc = output.loc, fct = "CV")
  
  # 2. Create a directory to store the results
  ############################################
  
  # create a directory to store the results of the QTL analysis
  
  end.char <- substr(output.loc, nchar(output.loc), nchar(output.loc))
  
  if(end.char == "/"){
    
    folder.loc <- paste0(output.loc, paste("MQE_CV",pop.name, trait.name,
                                           VCOV, sep = "_"))
    
  } else {
    
    folder.loc <- paste0(output.loc, "/", paste("MQE_CV",pop.name, trait.name,
                                                VCOV, sep = "_"))
    
  }
  
  dir.create(folder.loc)
  
  # 3. Create space to store the results
  ######################################
  
  # global results
  
  N.QTL <- p.ts <- p.vs <- bias <- rep(0, (k * Rep))
  
  # within cross pVS
  
  p.vs.cr <- matrix(0, mppData$n.cr, (k * Rep))
  
  ind.res <- 1 # index to feed the results later
  
  # individual QTL position results
  
  QTL.positions <- rep(0, dim(mppData$map)[1])
  N.Qeff.est.ts <- rep(0, dim(mppData$map)[1])
  N.Qeff.est.vs <- rep(0, dim(mppData$map)[1])
  
  QTL.cr <- rep(0, dim(mppData$map)[1])
  QTL.par <- rep(0, dim(mppData$map)[1])
  QTL.anc <- rep(0, dim(mppData$map)[1])
  QTL.biall <- rep(0, dim(mppData$map)[1])
  
  QTL.pts.d <- QTL.pvs.d <- rep(0, dim(mppData$map)[1])
  
  # keep the marker and in between position full list
  
  mk.list <- mppData$map[, 1]
  
  
  # 4. start to loop from 1 to r replicates
  ########################################
  
  for (i in 1:Rep) {
    
    if(!silence.print){
      
      cat(paste("CV repetition", i))
      cat("\n")
      
    }
    
    
    ### 4.1 generate a CV partition
    
    folds <- CV_partition(cross.ind = mppData$cross.ind, k = k)
    
    ### 4.2 iterate through the CV partition
    
    for (j in 1:k) {
      
      if(!silence.print){
        
        cat(paste("fold", j))
        cat("\n")
        
      }
      
      # training set
      
      mppData.ts <- mppData_subset(mppData = mppData,
                                   gen.list = folds[[j]]$train.set)
      
      if(!is.null(mppData_bi)){
        
        mppData_bi.ts <- mppData_subset(mppData = mppData_bi,
                                        gen.list = folds[[j]]$train.set)
        
      } else {
        
        mppData_bi.ts <- NULL
        
      }
      
      # validation set
      
      mppData.vs <- mppData_subset(mppData = mppData,
                                   gen.list = folds[[j]]$val.set)
      
      if(!is.null(mppData_bi)){
        
        mppData_bi.vs <- mppData_subset(mppData = mppData_bi,
                                        gen.list = folds[[j]]$val.set)
        
      } else {
        
        mppData_bi.vs <- NULL
        
      }
      
      prob.prog <- FALSE # indicator variable for a programmation problem
      
      # 4.2.1 determination of QTL model
      
      QTL <- MQE_forward(mppData = mppData.ts, mppData_bi = mppData_bi.ts,
                         Q.eff = Q.eff, par.clu = par.clu, VCOV = VCOV,
                         threshold = threshold, window = window,
                         parallel = parallel, cluster = cluster,
                         silence.print = silence.print)
      
      # 4.2.4 Optional backward elimination
      
      if (VCOV == "cr.err_fast") VCOV_eff <- "h.err" else VCOV_eff <- VCOV
      
      if(!is.null(QTL) & backward){
        
        QTL.back <- MQE_BackElim(mppData = mppData.ts, mppData_bi = mppData_bi.ts,
                                 QTL = QTL[, 1], Q.eff = QTL[, 5],
                                 par.clu = par.clu, VCOV = VCOV_eff,
                                 alpha = alpha.bk)
        
        if(is.null(QTL.back)){ # If there was QTL position and backward return
          # no QTL it is (probably) due to programming error.
          
          prob.prog <- TRUE
          QTL <- NULL
          
        } else {QTL <- QTL.back}
        
      }
      
      
      if (!is.null(QTL)) {
        
        
        ### 4.3 compute the CV statistics (N.QTL, p.ts. etc.)
        
        # a) N.QTL
        
        N.QTL[ind.res] <- dim(QTL)[1]
        
        # b) QTL positions
        
        QTL.names <- QTL[, 1]
        
        QTL.positions <- QTL.positions + (is.element(mk.list, QTL.names) * 1)
        
        # c) the type of QTL effect
        
        QTL.effect <- QTL[, 5]
        
        for(id in 1: dim(QTL)[1]){
          
          if(QTL.effect[id] == "cr"){
            
            QTL.cr <- QTL.cr + (is.element(mk.list, QTL.names[id]) * 1)
            
          } else if (QTL.effect[id] == "par") {
            
            QTL.par <- QTL.par + (is.element(mk.list, QTL.names[id]) * 1)  
            
          } else if (QTL.effect[id] == "anc") {
            
            QTL.anc <- QTL.anc + (is.element(mk.list, QTL.names[id]) * 1)
            
          } else if (QTL.effect[id] == "biall") {
            
            QTL.biall <- QTL.biall + (is.element(mk.list, QTL.names[id]) * 1)
            
          }
          
        }
        
        # d) p.ts (adjusted R2 / heritability)
        
        # get the R squared training set
        ################################
        
        
        R2.ts <- MQE_R2(mppData = mppData.ts, mppData_bi = mppData_bi.ts,
                        QTL = QTL[, 1], Q.eff = QTL[, 5], par.clu = par.clu,
                        R2.lik = ind.R2)
        
        
        
        # compute predicted R squared
        ##############################
        
        R2.vs <- MQE_pred_R2(mppData.ts = mppData.ts,
                             mppData_bi.ts = mppData_bi.ts,
                             mppData.vs = mppData.vs,
                             mppData_bi.vs = mppData_bi.vs, Q.eff = QTL[, 5],
                             par.clu = par.clu, VCOV = VCOV_eff, QTL = QTL[, 1],
                             her = her)
        
        # global results
        ################
        
        
        p.ts[ind.res] <- R2.ts$glb.R2/mean(her)
        p.vs[ind.res] <- R2.vs$glb.R2
        bias[ind.res] <- round(1 - (p.vs[ind.res]/p.ts[ind.res]), 2)
        
        
        # within cross results
        
        p.vs.cr[, ind.res] <- R2.vs$R2.cr
        
        
        # store partial R squared
        #########################
        
        # count the number of time partial QTL R2 could be estimated 
        
        if(!is.na(R2.vs[[1]])){ # validation set
          
          N.Qeff.est.vs <- N.Qeff.est.vs + (is.element(mk.list, QTL.names) * 1)
          
        }
        
        if(!is.na(R2.ts[[1]])){ # test set
          
          N.Qeff.est.ts <- N.Qeff.est.ts + (is.element(mk.list, QTL.names) * 1)
          
        }
        
        
        # general function to store individual QTL results
        
        update.res <- function(input, output, Q.names, mk.list){
          
          R.ij <- rep(0, length(mk.list))
          R.ij[match(Q.names, mk.list)] <- input
          rowSums(data.frame(output, R.ij), na.rm = TRUE)
          
        }
        
        
        # difference QTL R2 values
        
        QTL.pts.d <- update.res(input = R2.ts$part.R2.diff/mean(her),
                                output = QTL.pts.d, Q.names = QTL.names,
                                mk.list = mk.list)
        
        QTL.pvs.d <- update.res(input = R2.vs$part.R2.diff/mean(her),
                                output = QTL.pvs.d, Q.names = QTL.names,
                                mk.list = mk.list)
        
        
      } else {
        
        
        if(prob.prog){
          
          N.QTL[ind.res] <- p.ts[ind.res] <- p.vs[ind.res] <- NA
          bias[ind.res] <- NA
          
        } else { # only no QTL significant enough.
          
          # N.QTL p.ts and p.vs stay at 0 as in the initialisation. Only need to
          # put the bias at NA.
          
          bias[ind.res] <- NA
          
        }
        
      }
      
      ind.res <- ind.res + 1
      
    }  # end jth fold loop
    
    
  }  # end ith repetition loop
  
  
  # 5. save the results in the specified folder
  #############################################
  
  ### 5.1 global results
  
  CV_res <- data.frame(N.QTL, p.ts, p.vs, bias)
  CV_res <- round(CV_res, 2)
  
  write.table(CV_res, paste0(folder.loc, "/", "CV_res.txt"), quote = FALSE,
              sep = "\t", row.names = FALSE)
  
  p.vs.cr <- round(p.vs.cr, 2)
  rownames(p.vs.cr) <- unique(mppData$cross.ind)
  colnames(p.vs.cr) <- paste0("CV.run", 1:(Rep*k))
  
  write.table(p.vs.cr, paste0(folder.loc, "/", "p_vs_cr.txt"), quote = FALSE,
              sep = "\t")
  
  ### 5.2 ind QTL position res
  
  av.pts.d <- round(QTL.pts.d/N.Qeff.est.ts, 1)
  av.pvs.d <- round(QTL.pvs.d/N.Qeff.est.vs, 1)
  bias.d <- round(1 - (av.pvs.d/av.pts.d), 1)
  
  QTL.sum <- data.frame(mppData$map, QTL.positions, QTL.cr, QTL.par, QTL.anc,
                        QTL.biall, av.pts.d, av.pvs.d,
                        bias.d, stringsAsFactors = FALSE)
  
  QTL.sum <- QTL.sum[QTL.positions > 0, ]
  
  colnames(QTL.sum)[5:12] <- c("N", "n.cr", "n.par", "n.anc", "n.biall", "p.ts",
                               "p.vs", "bias")
  
  write.table(QTL.sum, paste0(folder.loc, "/", "QTL.txt"), quote = FALSE,
              sep = "\t", row.names = FALSE)
  
  
  # return R object
  
  return(list(CV_res = CV_res, p.vs.cr = p.vs.cr, QTL = QTL.sum))
  
}