###############
# MQE_pred_R2 #
###############

# Predicted QTL global and partial R squared for a multi-QTL effect list


MQE_pred_R2 <- function(mppData.ts, mppData_bi.ts, mppData.vs, mppData_bi.vs,
                        Q.eff, par.clu = NULL, VCOV = "h.err", QTL, her) {
  
  
  # 1. obtain the genetic effects (Betas)
  #######################################
  
  if(("biall" %in% Q.eff) || ("cr" %in% Q.eff)){
    if(!is.null(mppData.ts$geno.par)) {mppData.ts$geno.par <- NULL}
    if(!is.null(mppData_bi.ts$geno.par)) {mppData_bi.ts$geno.par <- NULL}
  }
  
  
  effects <- MQE_genEffects(mppData = mppData.ts,
                            mppData_bi = mppData_bi.ts, QTL = QTL,
                            Q.eff = Q.eff, par.clu = par.clu,
                            VCOV = VCOV)
  
  # re-order the parental and ancestral scores
  
  for(i in 1:length(QTL)){
    
    eff.i <- effects[[i]]
    
    if(Q.eff[i] == "par"){
      
      eff.names <- strsplit(x = rownames(effects[[i]]),
                            split = paste0("Q", i))
      eff.names <- unlist(lapply(X = eff.names, FUN = function(x) x[2]))
      index <- match(eff.names, mppData.vs$parents)
      effects[[i]] <- eff.i[index, ]
      
    } else if (Q.eff[i] == "anc"){
      
      effects[[i]] <- eff.i[mppData.vs$parents, ]
      
    }
    
  }
  
  
  B.ts <- lapply(X = seq_along(effects), FUN = function(x, Qeff) Qeff[[x]][, 1],
                 Qeff = effects)
  
  # 2. obtain the QTL incidence matrices of the positions (X.vs)
  ##############################################################
  
  cross.mat <- IncMat_cross(cross.ind = mppData.vs$cross.ind)
  parent.mat <- IncMat_parent(mppData.vs)
  
  Q.pos <- which(mppData.vs$map[, 1] %in% QTL)
  
  # replace ancestral by parental to form the QTL incidence matrices
  
  Q.eff[Q.eff == "anc"] <- "par"
  
  Q.list <- mapply(FUN = IncMat_QTL_MQE, x = Q.pos, Q.eff = Q.eff,
                   MoreArgs = list(mppData = mppData.vs,
                                   mppData_bi = mppData_bi.vs,
                                   par.clu = par.clu,
                                   cross.mat = cross.mat,
                                   par.mat = parent.mat),
                   SIMPLIFY = FALSE)
  
  # re-order the parental columns
  
  for (i in 1:length(Q.list)){
    
    Q.i <- Q.list[[i]]
    if (Q.eff[i] == "par"){Q.list[[i]] <- Q.i[, mppData.vs$parents]}
    
  }
  
  names(Q.list) <- paste0("Q", 1:length(Q.list))
  
  n.QTL <- length(Q.list)
  
  
  
  # 3. Predicted R squared computation cor(y.vs, X.vs * B.ts)^2
  ##############################################################
  
  
  R2 <- R2_pred(mppData.vs = mppData.vs, B.ts = B.ts, Q.list = Q.list,
                her = her)
  
  # partial R2
  
  if (n.QTL > 1) {
    
    part.R2.diff <- function(x, mppData.vs, B.ts, Q.list, her) {
      R2_pred(mppData.vs = mppData.vs, B.ts = B.ts[-x],
              Q.list =  Q.list[-x], her = her)[[1]]
    }
    
    
    R2_i.dif <- lapply(X = 1:n.QTL, FUN = part.R2.diff, mppData.vs = mppData.vs,
                       B.ts = B.ts, Q.list = Q.list, her = her)
    
    R2_i.dif <- R2[[1]] - unlist(R2_i.dif) # difference full model and model minus i
    
    
    names(R2_i.dif) <- paste0("Q", 1:n.QTL)
    
    
    return(list(glb.R2 = R2[[1]], R2.cr = R2[[2]],
                part.R2.diff = R2_i.dif))
    
  } else {
    
    R2.Q1 <- R2[[1]]
    names(R2.Q1) <- "Q1"
    
    return(list(glb.R2 = R2[[1]], R2.cr = R2[[2]],
                part.R2.diff = R2.Q1))
    
  }
  
  
}